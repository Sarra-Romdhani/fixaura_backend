import { Controller, Post, Body, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { firstValueFrom } from 'rxjs';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Conversation, ConversationDocument } from './Conversation.schema';

@Controller('chatbot')
export class ChatbotController {
  private readonly logger = new Logger(ChatbotController.name);

  constructor(
    private readonly httpService: HttpService,
    @InjectModel(Conversation.name) private conversationModel: Model<ConversationDocument>,
  ) {}

  private getErrorMessage(lang: string): string {
    const errors = {
      tn: 'مشكلة تقنية! جربي مرة أخرى.',
      en: 'Technical issue! Try again later.',
      fr: 'Problème technique ! Réessayez plus tard.',
      ar: 'مشكلة تقنية! حاول مرة أخرى لاحقًا.',
    };
    return errors[lang] || errors.fr;
  }

  @Post('message')
  async handleMessage(
    @Body() body: { userId: string; message: string; language: string; conversationId?: string },
  ): Promise<{ response: string; conversationId: string }> {
    this.logger.log(`Received: ${body.message}, lang: ${body.language}`);
    try {
      // Input validation
      if (!body.userId || !body.message || !['fr', 'en', 'tn', 'ar'].includes(body.language)) {
        throw new HttpException('Invalid input', HttpStatus.BAD_REQUEST);
      }

      const fastApiUrl = 'http://127.0.0.1:8000/chatbot/message';
      this.logger.log(`Sending request to FastAPI: ${JSON.stringify({ message: body.message, language: body.language })}`);
      let response;
      try {
        // Call FastAPI with increased timeout (180 seconds)
        response = await firstValueFrom(
          this.httpService.post(
            fastApiUrl,
            { message: body.message, language: body.language },
            { timeout: 180000, headers: { 'Content-Type': 'application/json' } },
          ),
        );
        this.logger.log(`Received response from FastAPI: ${JSON.stringify(response.data)}`);
      } catch (error) {
        // Handle timeout specifically
        if (error.code === 'ECONNABORTED') {
          this.logger.error('FastAPI request timed out');
          throw new HttpException(
            'AI service is taking too long to respond. Please try again later.',
            HttpStatus.SERVICE_UNAVAILABLE,
          );
        }
        this.logger.error(`FastAPI error: ${error.message}`);
        throw new Error('AI service failed');
      }

      const finalResponse = response.data.response || this.getErrorMessage(body.language);

      // Handle conversation in MongoDB
      let conversation: ConversationDocument;
      if (body.conversationId) {
        const updatedConversation = await this.conversationModel.findOneAndUpdate(
          { _id: body.conversationId, userId: body.userId },
          {
            $push: {
              messages: [
                { text: body.message, isUser: true, timestamp: new Date() },
                { text: finalResponse, isUser: false, timestamp: new Date() },
              ],
            },
            $set: {
              lastLanguage: body.language,
              updatedAt: new Date(),
              direction: ['ar', 'tn'].includes(body.language) ? 'rtl' : 'ltr',
            },
          },
          { new: true },
        );
        if (!updatedConversation) {
          throw new HttpException('Conversation not found', HttpStatus.NOT_FOUND);
        }
        conversation = updatedConversation;
      } else {
        conversation = await this.conversationModel.create({
          userId: body.userId,
          messages: [
            { text: body.message, isUser: true, timestamp: new Date() },
            { text: finalResponse, isUser: false, timestamp: new Date() },
          ],
          lastLanguage: body.language,
          updatedAt: new Date(),
          direction: ['ar', 'tn'].includes(body.language) ? 'rtl' : 'ltr',
        });
      }

      return { response: finalResponse, conversationId: conversation.id.toString() };
    } catch (error) {
      this.logger.error(`Error: ${error.message}`);
      throw new HttpException(
        { response: this.getErrorMessage(body?.language || 'fr'), error: error.message },
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }
}