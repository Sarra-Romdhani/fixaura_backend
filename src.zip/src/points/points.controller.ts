import { Controller } from '@nestjs/common';

@Controller('points')
export class PointsController {}
